<?php
	$ptX = 0;
	$ptY = 0;
	$direction = '';
	
	$_isDebugChecked = False;
	
	if ($_GET['ptX']) {
		$ptX = $_GET['ptX'];
	}

	if ($_GET['ptY']) {
		$ptY = $_GET['ptY'];
	}

	if ($_GET['direction']) {
		$direction = $_GET['direction'];
	}

	if ($_POST['ptX']) {
		$ptX = $_POST['ptX'];
	}

	if ($_POST['ptY']) {
		$ptY = $_POST['ptY'];
	}

	if ($_POST['direction']) {
		$direction = $_POST['direction'];
	}

	$validDirections = 'NSEW';
	$northDirection = 'N';
	$southDirection = 'S';
	$eastDirection = 'E';
	$westDirection = 'W';
	$validCommands = 'LRM';
	$leftCommand = 'L';
	$rightCommand = 'R';
	$moveCommand = 'M';
	function isDebugChecked() {
		global $_isDebugChecked;
		return $_isDebugChecked;
	}
	function debugOut($msg) {
		if (isDebugChecked()) {
			echo $msg.'<BR/>';
		}
	}
	function doMove() {
		global $direction, $northDirection, $eastDirection, $southDirection, $westDirection, $ptX, $ptY;
		switch ($direction) {
			case $northDirection:
				debugOut('doMove().1 -> ($direction == $northDirection)');
				$ptY = $ptY + 1;
				break;
			case $eastDirection:
				debugOut('doMove().2 -> ($direction == $eastDirection)');
				$ptX = $ptX + 1;
				break;
			case $southDirection:
				debugOut('doMove().3 -> ($direction == $southDirection)');
				$ptY = $ptY - 1;
				break;
			case $westDirection:
				debugOut('doMove().4 -> ($direction == $westDirection)');
				$ptX = $ptX - 1;
				break;
		}
	}
	function doSpin($d) {
		global $direction, $validDirections, $validCommands;
		$direction = ( (strpos($validDirections, $d) >= 0) || (strpos($validCommands, $d) >= 0) ) ? $d : $direction;
		debugOut('doSpin().1 --> d='.$d.', $direction='.$direction);
	}
	function doCommand($c) {
		global $leftCommand, $rightCommand, $moveCommand, $direction, $northDirection, $westDirection, $southDirection, $eastDirection;
		debugOut('doCommand().1 --> c='.$c);
		switch ($c) {
			case $leftCommand:
				debugOut('doCommand().2 --> (c == $leftCommand)');
				switch ($direction) {
					case $northDirection:
						debugOut('doCommand().3 --> doSpin($westDirection)');
						doSpin($westDirection);
						break;
					case $westDirection:
						debugOut('doCommand().4 --> doSpin($southDirection)');
						doSpin($southDirection);
						break;
					case $southDirection:
						debugOut('doCommand().5 --> doSpin($eastDirection)');
						doSpin($eastDirection);
						break;
					case $eastDirection:
						debugOut('doCommand().6 --> doSpin($northDirection)');
						doSpin($northDirection);
						break;
				}
				break;
			case $rightCommand:
				debugOut('doCommand().7 --> (c == $rightCommand)');
				switch ($direction) {
					case $northDirection:
						debugOut('doCommand().8 --> doSpin($eastDirection)');
						doSpin($eastDirection);
						break;
					case $eastDirection:
						debugOut('doCommand().9 --> doSpin($southDirection)');
						doSpin($southDirection);
						break;
					case $southDirection:
						debugOut('doCommand().10 --> doSpin($westDirection)');
						doSpin($westDirection);
						break;
					case $westDirection:
						debugOut('doCommand().11 --> doSpin($northDirection)');
						doSpin($northDirection);
						break;
				}
				break;
			case $moveCommand:
				debugOut('doCommand().12 --> (c == $moveCommand)');
				doMove();
				break;
		}
	}
	function parseCommand($c) {
		global $validDirections, $validCommands, $ptX, $ptY, $direction;
		$tests = array();
		$items = array();
		$toks = explode(" ", $c);
		for ($i=0; $i < count($toks); $i++) {
			$aTok = $toks[$i];
			debugOut('parseCommand().1 aTok='.$aTok);
			if (strlen($aTok) > 1) {
				for ($j = 0; $j < strlen($aTok); $j++) {
					$aCmd = substr($aTok,$j,1);
					debugOut('parseCommand().2 aCmd='.$aCmd);
					doCommand($aCmd);
				}
			} else {
				$b = is_numeric($aTok);
				debugOut('parseCommand().3 --> b='.$b);
				if ($b) {
					array_push($tests, $b);
					array_push($items, $aTok);
					debugOut('parseCommand().4 tests.length='.count($tests));
					if ( (count($tests) == 2) && ($tests[0] == true) && ($tests[1] == true) ) {
						$ptX = (int)array_shift($items);
						$ptY = (int)array_shift($items);
						$b = array_shift($tests);
						$b = array_shift($tests);
					}
				} else {
					if (strpos($validDirections,$aTok) >= 0) {
						$direction = $aTok;
						debugOut('parseCommand().5 $direction='.$direction);
					} else {
						if (strpos($validCommands,$aTok) >= 0) {
							debugOut('parseCommand().6 doCommand('.$aTok.')');
							doCommand($aTok);
						}
					}
				}
			}
		}
	}
	if ($_GET['command']) {
		parseCommand($_GET['command']);
	}

	if ($_POST['command']) {
		parseCommand($_GET['command']);
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
       "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
  <title>Mars Rover Sample PHP 5.3.2</title>
	<style type="text/css">
		html {
			background-color: white;
		}
		
		body {
			font-family: Verdana, Geneva, Arial, Helvetica, sans-serif;
			font-size: 14px;
			color: black;
			background-color: white;
			text-align: left;
		}
	</style>
</head>
<body>

<p style="color: green"><?php ?></p>

<h1>Mars Rover Status <small>(<a href="marsRover.php">restart</a>)</small></h1>
<h2><?php
if (!defined('PHP_VERSION_ID')) {
    $version = explode('.', PHP_VERSION);

    define('PHP_VERSION_ID', ($version[0] * 10000 + $version[1] * 100 + $version[2]));
}
if (PHP_VERSION_ID < 50207) {
    define('PHP_MAJOR_VERSION',   $version[0]);
    define('PHP_MINOR_VERSION',   $version[1]);
    define('PHP_RELEASE_VERSION', $version[2]);
}
echo 'PHP '.PHP_VERSION_ID;
?></h2>
<h3>Notice the PHP 5.3.2 Version runs independent from the JavaScript/jQuery Version.</h3>

<table>
  <tr>
    <th align="center">X-Coord</th>
    <th align="center">Y-Coord</th>
    <th align="center">Direction</th>
  </tr>
  
  <tr>
    <td align="center"><?php echo $ptX; ?></td>
    <td align="center"><?php echo $ptY; ?></td>
    <td align="center"><?php echo $direction; ?></td>
  </tr>

</table>

<br />
<p>Enter the Rover Commands below and watch the output from each command. <a href="#info-toggle" id="a_info" onclick="javascript:window.parent.toggleInfo();"><big><b>?</b></big></a></p>
<form action="marsRover.php" enctype="application/x-www-form-urlencoded">
	<b>Command: </b>&nbsp;<input id="command" name="command" size="30" />&nbsp;&nbsp;
	<input type="hidden" name="ptX" value="<?php echo $ptX; ?>"/>
	<input type="hidden" name="ptY" value="<?php echo $ptY; ?>"/>
	<input type="hidden" name="direction" value="<?php echo $direction; ?>"/>
	<input id="btnSubmit" type="submit" value="Submit"/>
</form>

</body>
</html>
