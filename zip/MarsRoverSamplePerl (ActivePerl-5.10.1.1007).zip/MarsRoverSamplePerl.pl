#!/usr/bin/perl -w
use strict;

$main::i_ptX = 0;
$main::i_ptY = 0;
$main::s_direction = '';
$main::validDirections = 'NSEW';
$main::northDirection = 'N';
$main::southDirection = 'S';
$main::eastDirection = 'E';
$main::westDirection = 'W';
$main::validCommands = 'LRM';
$main::leftCommand = 'L';
$main::rightCommand = 'R';
$main::moveCommand = 'M';

$main::isDebugChecked = 0;

sub debugOut # arg1 is the string to be printed...
    {
        if ($main::isDebugChecked) {
            print $_[0],"\n";
        }
    }

sub publish_values
    {
        my($i_ptX) = $main::i_ptX;
        my($i_ptY) = $main::i_ptY;
        my($s_direction) = $main::s_direction;
        print "$i_ptX $i_ptY $s_direction\n";
    }
    
sub doMove
    {
        if ($main::s_direction eq $main::northDirection) {
                debugOut("doMove().1 --> (main::s_direction == main::northDirection)");
                $main::i_ptY = $main::i_ptY + 1;
        } elsif ($main::s_direction eq $main::eastDirection) {
                debugOut("doMove().2 --> (main::s_direction == eastDirection)");
                $main::i_ptX = $main::i_ptX + 1;
        } elsif ($main::s_direction eq $main::southDirection) {
                debugOut("doMove().3 --> (main::s_direction == southDirection)");
                $main::i_ptY = $main::i_ptY - 1;
        } elsif ($main::s_direction eq $main::westDirection) {
                debugOut("doMove().4 --> (main::s_direction == westDirection)");
                $main::i_ptX = $main::i_ptX - 1;
        }
    }
    

sub doSpin # arg1 is the "d"
    {
        my($d) = $_[0];
        if ((index($main::validDirections,$d) > -1) or (index($main::validCommands,$d) > -1)) {
            $main::s_direction = $d;
        }
        debugOut("doSpin().1 --> d=$d, s_direction=$main::s_direction");
    }

sub doCommand # arg1 is the "c"
    {
        my($c) = $_[0];
        debugOut("doCommand().1 --> c=$c");
        if ($c eq $main::leftCommand) {
            debugOut("doCommand().2 --> (c == leftCommand)");
            if ($main::s_direction eq $main::northDirection) {
                debugOut("doCommand().3 --> doSpin(westDirection)");
                doSpin($main::westDirection);
            } elsif ($main::s_direction eq $main::westDirection) {
                debugOut("doCommand().4 --> doSpin(southDirection)");
                doSpin($main::southDirection);
            } elsif ($main::s_direction eq $main::southDirection) {
                debugOut("doCommand().5 --> doSpin(eastDirection)");
                doSpin($main::eastDirection);
            } elsif ($main::s_direction eq $main::eastDirection) {
                debugOut("doCommand().6 --> doSpin(northDirection)");
                doSpin($main::northDirection);
            }
        } elsif ($c eq $main::rightCommand) {
            debugOut("doCommand().7 --> (c == rightCommand)");
            if ($main::s_direction eq $main::northDirection) {
                debugOut("doCommand().8 --> doSpin(eastDirection)");
                doSpin($main::eastDirection);
            } elsif ($main::s_direction eq $main::eastDirection) {
                debugOut("doCommand().9 --> doSpin(southDirection)");
                doSpin($main::southDirection);
            } elsif ($main::s_direction eq $main::southDirection) {
                debugOut("doCommand().10 --> doSpin(westDirection)");
                doSpin($main::westDirection);
            } elsif ($main::s_direction eq $main::westDirection) {
                debugOut("doCommand().11 --> doSpin(northDirection)");
                doSpin($main::northDirection);
            }
        } elsif ($c eq $main::moveCommand) {
            debugOut("doCommand().12 --> (c == moveCommand)");
            doMove();
        }
    }

sub is_integer { $_[0] =~ /^[+-]?\d+$/ }

sub parseCommand # arg1 is the "c"
    {
        my($c) = $_[0];
        my($aTok) = '';
        my($aCmd) = '';
        my($b) = 0;
        my(@tests) = ();
        my(@items) = ();
        my(@toks) = split(/ /, $c);
        my($i) = 0;
        my($j) = 0;
        my($l) = 0;
        my($l_toks) = scalar @toks;
        for ($i = 0; $i < $l_toks; $i++) {
            $aTok = $toks[$i];
            debugOut("parseCommand().1 aTok=$aTok");
            if (length($aTok) > 1) {
                for ($j = 0; $j < length($aTok); $j++) {
                    $aCmd = substr($aTok,$j,1);
                    debugOut("parseCommand().2 aCmd=$aCmd");
                    doCommand($aCmd);
                }
            } else {
                $b = is_integer($aTok);
                debugOut("parseCommand().3 --> b=$b");
                if ($b) {
                    push(@tests,$b);
                    push(@items,$aTok);
                    $l = scalar @tests;
                    debugOut("parseCommand().4 tests.length=$l");
                    if ( ($l == 2) and ($tests[0]) && ($tests[1]) ) {
                            $main::i_ptX = int(shift(@items));
                            $main::i_ptY = int(shift(@items));
                            $b = shift(@tests);
                            $b = shift(@tests);
                    }
                } elsif (index($main::validDirections,$aTok) > -1) {
                        $main::s_direction = $aTok;
                        debugOut("parseCommand().5 s_direction=$main::s_direction");
                } elsif (index($main::validCommands,$aTok) > -1) {
                        debugOut("parseCommand().6 doCommand($aTok)");
                        doCommand($aTok);
                }
            }
        }
    }
    

debugOut('+++');
publish_values();

@main::tests = (  "1 2 N;1 2 N",
                    "L;1 2 W",
                    "M;0 2 W",
                    "L;0 2 S",
                    "M;0 1 S",
                    "L;0 1 E",
                    "M;1 1 E",
                    "L;1 1 N",
                    "M;1 2 N",
                    "M;1 3 N",
                    "3 3 E;3 3 E",
                    "M;4 3 E",
                    "M;5 3 E",
                    "R;5 3 S",
                    "M;5 2 S",
                    "M;5 1 S",
                    "R;5 1 W",
                    "M;4 1 W",
                    "R;4 1 N",
                    "R;4 1 E",
                    "M;5 1 E",
                    "1 2 N;1 2 N",
                    "LMLMLMLMM;1 3 N",
                    "3 3 E;3 3 E",
                    "MMRMMRMRRM;5 1 E");
#@main::tests = (  "1 2 N;1 2 N");
print "BEGIN:\tIf you don't see any ERROR messages then all tests worked as expected.\n";
$main::l_tests = scalar @main::tests;
$main::num_errors = 0;
for ($main::i = 0; $main::i < $main::l_tests; $main::i++) {
    @main::toks = split(/;/, $main::tests[$main::i]);
    #$main::l_toks = scalar @main::toks;
    $main::cmd = $main::toks[0];
    $main::expected = $main::toks[1];
    #print "$main::tests[$main::i] -> l_toks=$main::l_toks, cmd=$main::cmd, expected=$main::expected\n";
    parseCommand($main::cmd);
    $main::x = "$main::i_ptX $main::i_ptY $main::s_direction";
    #print "$main::x -> $main::expected\n";
    if ($main::x ne $main::expected) {
        print "ERROR #$main::i\n";
        $main::num_errors++;
    }
}
if ($main::num_errors == 0) {
    print "\tThere were NO errors reported.\n";
}
print "END:\tIf you don't see any ERROR messages then all tests worked as expected.\n";
