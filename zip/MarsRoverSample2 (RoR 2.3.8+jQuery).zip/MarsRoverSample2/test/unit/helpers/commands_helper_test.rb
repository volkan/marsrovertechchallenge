require 'test_helper'

class CommandsHelperTest < ActionView::TestCase
end
