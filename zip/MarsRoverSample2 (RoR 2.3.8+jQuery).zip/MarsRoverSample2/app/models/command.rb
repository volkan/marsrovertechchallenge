class Command < ActiveRecord::Base
end
