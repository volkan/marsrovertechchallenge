﻿Module Module1

    Dim i_ptX As Integer = 0
    Dim i_ptY As Integer = 0
    Dim s_direction As String = ""
    Dim validDirections As String = "NSEW"
    Dim northDirection As String = "N"
    Dim southDirection As String = "S"
    Dim eastDirection As String = "E"
    Dim westDirection As String = "W"
    Dim validCommands As String = "LRM"
    Dim leftCommand As String = "L"
    Dim rightCommand As String = "R"
    Dim moveCommand As String = "M"

    Dim isDebugChecked As Boolean = False

    Sub debugOut(ByVal msg As String)
        If (isDebugChecked) Then
            Console.WriteLine(msg)
        End If
    End Sub

    Function publish_values()
        Dim s As String = "" + i_ptX.ToString + " " + i_ptY.ToString + " " + s_direction
        Console.WriteLine(s)
        Return s
    End Function

    Sub doMove()
        If (s_direction = northDirection) Then
            debugOut("doMove().1 --> (s_direction == northDirection)")
            i_ptY = i_ptY + 1
        ElseIf (s_direction = eastDirection) Then
            debugOut("doMove().2 --> (s_direction == eastDirection)")
            i_ptX = i_ptX + 1
        ElseIf (s_direction = southDirection) Then
            debugOut("doMove().3 --> (s_direction == southDirection)")
            i_ptY = i_ptY - 1
        ElseIf (s_direction = westDirection) Then
            debugOut("doMove().4 --> (s_direction == westDirection)")
            i_ptX = i_ptX - 1
        End If
    End Sub

    Sub doSpin(ByVal d)
        If ((validDirections.IndexOf(d) > -1) Or (validCommands.IndexOf(d) > -1)) Then
            s_direction = d
        End If
        debugOut("doSpin().1 --> d=" + d + ", s_direction=" + s_direction)
    End Sub

    Sub doCommand(ByVal c)
        debugOut("doCommand().1 --> c=" + c)
        If (c = leftCommand) Then
            debugOut("doCommand().2 --> (c == leftCommand)")
            If (s_direction = northDirection) Then
                debugOut("doCommand().3 --> doSpin(westDirection)")
                doSpin(westDirection)
            ElseIf (s_direction = westDirection) Then
                debugOut("doCommand().4 --> doSpin(southDirection)")
                doSpin(southDirection)
            ElseIf (s_direction = southDirection) Then
                debugOut("doCommand().5 --> doSpin(eastDirection)")
                doSpin(eastDirection)
            ElseIf (s_direction = eastDirection) Then
                debugOut("doCommand().6 --> doSpin(northDirection)")
                doSpin(northDirection)
            End If
        ElseIf (c = rightCommand) Then
            debugOut("doCommand().7 --> (c == rightCommand)")
            If (s_direction = northDirection) Then
                debugOut("doCommand().8 --> doSpin(eastDirection)")
                doSpin(eastDirection)
            ElseIf (s_direction = eastDirection) Then
                debugOut("doCommand().9 --> doSpin(southDirection)")
                doSpin(southDirection)
            ElseIf (s_direction = southDirection) Then
                debugOut("doCommand().10 --> doSpin(westDirection)")
                doSpin(westDirection)
            ElseIf (s_direction = westDirection) Then
                debugOut("doCommand().11 --> doSpin(northDirection)")
                doSpin(northDirection)
            End If
        ElseIf (c = moveCommand) Then
            debugOut("doCommand().12 --> (c == moveCommand)")
            doMove()
        End If
    End Sub

    Function IsInteger(ByVal theValue As String) As Boolean
        Try
            Convert.ToInt32(theValue)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    Function parseCommand(ByVal c As String) As String
        Dim i As Integer
        Dim aTok As String
        Dim aCmd As String
        Dim b As Boolean
        Dim items As Stack = New Stack()
        Dim toks As String() = c.Split(New [Char]() {" "c})
        For i = 0 To toks.Length - 1
            aTok = toks(i)
            debugOut("parseCommand().1 aTok=" + aTok)
            If (aTok.Length > 1) Then
                For j = 0 To aTok.Length - 1
                    aCmd = aTok.Substring(j, 1)
                    debugOut("parseCommand().2 aCmd=" + aCmd)
                    doCommand(aCmd)
                Next
            Else
                b = IsInteger(aTok)
                debugOut("parseCommand().3 --> b=" + b.ToString)
                If (b) Then
                    items.Push(aTok)
                    debugOut("parseCommand().4 items.Count=" + items.Count.ToString)
                    If (items.Count = 2) Then
                        i_ptY = Convert.ToInt32(items.Pop())
                        i_ptX = Convert.ToInt32(items.Pop())
                    End If
                ElseIf (validDirections.IndexOf(aTok) > -1) Then
                    s_direction = aTok
                    debugOut("parseCommand().5 s_direction=" + s_direction)
                ElseIf (validCommands.IndexOf(aTok) > -1) Then
                    debugOut("parseCommand().6 doCommand(" + aTok + ")")
                    doCommand(aTok)
                End If
            End If
        Next
        Dim retVal As String = publish_values()
        Return retVal
    End Function

    Sub Main()
        Dim tests(25) As String

        tests(1) = "1 2 N;1 2 N"
        tests(2) = "L;1 2 W"
        tests(3) = "M;0 2 W"
        tests(4) = "L;0 2 S"
        tests(5) = "M;0 1 S"
        tests(6) = "L;0 1 E"
        tests(7) = "M;1 1 E"
        tests(8) = "L;1 1 N"
        tests(9) = "M;1 2 N"
        tests(10) = "M;1 3 N"
        tests(11) = "3 3 E;3 3 E"
        tests(12) = "M;4 3 E"
        tests(13) = "M;5 3 E"
        tests(14) = "R;5 3 S"
        tests(15) = "M;5 2 S"
        tests(16) = "M;5 1 S"
        tests(17) = "R;5 1 W"
        tests(18) = "M;4 1 W"
        tests(19) = "R;4 1 N"
        tests(20) = "R;4 1 E"
        tests(21) = "M;5 1 E"
        tests(22) = "1 2 N;1 2 N"
        tests(23) = "LMLMLMLMM;1 3 N"
        tests(24) = "3 3 E;3 3 E"
        tests(25) = "MMRMMRMRRM;5 1 E"

        Dim cmd As String
        Dim expected As String
        Dim x As String
        Dim toks As String()

        Dim s As String
        Dim sep As Char = Chr(59)
        For i = 1 To tests.Length - 1
            s = tests(i)
            toks = s.Split(sep)
            cmd = toks(0)
            expected = toks(1)
            x = parseCommand(cmd)
            If (x <> expected) Then
                Console.WriteLine("ERROR #" + i)
            End If
        Next

    End Sub

End Module
