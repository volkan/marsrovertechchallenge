-- Mars Rover Technical Challenge

-- package.path = "." .. package.path

-- require "underscore"

i_ptX = 0
i_ptY = 0
s_direction = ''
validDirections = 'NSEW'
northDirection = 'N'
southDirection = 'S'
eastDirection = 'E'
westDirection = 'W'
validCommands = 'LRM'
leftCommand = 'L'
rightCommand = 'R'
moveCommand = 'M'

isDebugChecked = false

function debugOut(msg)
	if (isDebugChecked) then
		print(msg)
	end
end

function publish_values()
	local s = i_ptX..' '..i_ptY..' '..s_direction
	print(s)
	return s
end

function doMove()
	if (s_direction == northDirection) then
		debugOut('doMove().1 --> (s_direction == northDirection)')
		i_ptY = i_ptY + 1
	elseif (s_direction == eastDirection) then
		debugOut('doMove().2 --> (s_direction == eastDirection)')
		i_ptX = i_ptX + 1
	elseif (s_direction == southDirection) then
		debugOut('doMove().3 --> (s_direction == southDirection)')
		i_ptY = i_ptY - 1
	elseif (s_direction == westDirection) then
		debugOut('doMove().4 --> (s_direction == westDirection)')
		i_ptX = i_ptX - 1
	end
end

function fif(condition, if_true, if_false)
  if condition then return if_true else return if_false end
end

function doSpin(d)
	local b = ( (string.find(validDirections, d)) or (string.find(validCommands, d)) )
	s_direction = fif(b, d, s_direction)
	debugOut('doSpin().1 --> d='..d..', s_direction='..s_direction)
end


function doCommand(c)
	debugOut('doCommand().1 --> c='..c)
	if (c == leftCommand) then
		debugOut('doCommand().2 --> (c == leftCommand)')
		if (s_direction == northDirection) then
			debugOut('doCommand().3 --> doSpin(westDirection)')
			doSpin(westDirection)
		elseif (s_direction == westDirection) then
			debugOut('doCommand().4 --> doSpin(southDirection)')
			doSpin(southDirection)
		elseif (s_direction == southDirection) then
			debugOut('doCommand().5 --> doSpin(eastDirection)')
			doSpin(eastDirection)
		elseif (s_direction == eastDirection) then
			debugOut('doCommand().6 --> doSpin(northDirection)')
			doSpin(northDirection)
		end
	elseif (c == rightCommand) then
		debugOut('doCommand().7 --> (c == rightCommand)')
		if (s_direction == northDirection) then
			debugOut('doCommand().8 --> doSpin(eastDirection)')
			doSpin(eastDirection)
		elseif (s_direction == eastDirection) then
			debugOut('doCommand().9 --> doSpin(southDirection)')
			doSpin(southDirection)
		elseif (s_direction == southDirection) then
			debugOut('doCommand().10 --> doSpin(westDirection)')
			doSpin(westDirection)
		elseif (s_direction == westDirection) then
			debugOut('doCommand().11 --> doSpin(northDirection)')
			doSpin(northDirection)
		end
	elseif (c == moveCommand) then
		debugOut('doCommand().12 --> (c == moveCommand)')
		doMove()
	end
end

function strsplit(delimiter, text)
  local list = {}
  local pos = 1
  if string.find("", delimiter, 1) then
    error("delimiter matches empty string!")
  end
  while 1 do
    local first, last = string.find(text, delimiter, pos)
    if first then -- found?
      table.insert(list, string.sub(text, pos, first-1))
      pos = last+1
    else
      table.insert(list, string.sub(text, pos))
      break
    end
  end
  return list
end

function isNumeric(a)
    return type(tonumber(a)) == "number"
end

function booleanToString( b )
  if (b) then
    return "true"
  else
    return "false"
  end
end

function getn(t)
  if type(t.n) == "number" then return t.n end
  local max = 0
  for i,aTok in ipairs(t) do
    if type(i) == "number" and i>max then max=i end
  end
  return max
end

function parseCommand(c)
	local aTok
	local aCmd
	local b, b1, b2
	local i, j, l, n
	local tests = {}
	local items = {}
	local toks = strsplit(' ', c)
	for i,aTok in ipairs(toks) do
		debugOut('parseCommand().1 aTok='..aTok)
		l = string.len(aTok)
		debugOut('parseCommand().1a l='..l)
		if (l > 1) then
			for j = 1, l, 1 do
				debugOut('+++ parseCommand().2 j='..j)
				aCmd = string.sub(aTok, j, j)
				debugOut('+++ parseCommand().2a aCmd='..aCmd)
				doCommand(aCmd)
			end
		else
			b = isNumeric(aTok)
			debugOut('parseCommand().3 --> b='..booleanToString(b))
			if (b) then
				table.insert(tests,b)
				table.insert(items,aTok)
				n = getn(tests)
				debugOut('parseCommand().4 tests.length='..n)
				if (n == 2) then
					b1 = table.remove(tests, 1)
					debugOut('parseCommand().4a --> b1='..booleanToString(b1)..'\n')
					b2 = table.remove(tests, 1)
					debugOut('parseCommand().4b --> b2='..booleanToString(b2)..'\n')
					i_ptX = tonumber(table.remove(items, 1))
					debugOut('parseCommand().4b --> b2='..i_ptX..'\n')
					i_ptY = tonumber(table.remove(items, 1))
					debugOut('parseCommand().4b --> b2='..i_ptY..'\n')
				end
			elseif (string.find(validDirections, aTok)) then
				s_direction = aTok
				debugOut('parseCommand().5 s_direction='..s_direction)
			elseif (string.find(validCommands, aTok)) then
				debugOut('parseCommand().6 doCommand('..aTok..')')
				doCommand(aTok)
			end
		end
	end
	return publish_values()
end

x = parseCommand('1 2 N')
if not (x == '1 2 N') then error("Oops, programming error #1.") end

x = parseCommand('L')
if not (x == '1 2 W') then error("Oops, programming error #2.") end

x = parseCommand('M')
if not (x == '0 2 W') then error("Oops, programming error #3.") end

x = parseCommand('L')
if not (x == '0 2 S') then error("Oops, programming error #4.") end

x = parseCommand('M')
if not (x == '0 1 S') then error("Oops, programming error #5.") end

x = parseCommand('L')
if not (x == '0 1 E') then error("Oops, programming error #6.") end

x = parseCommand('M')
if not (x == '1 1 E') then error("Oops, programming error #7.") end

x = parseCommand('L')
if not (x == '1 1 N') then error("Oops, programming error #8.") end

x = parseCommand('M')
if not (x == '1 2 N') then error("Oops, programming error #9.") end

x = parseCommand('M')
if not (x == '1 3 N') then error("Oops, programming error #10.") end


x = parseCommand('1 2 N')
if not (x == '1 2 N') then error("Oops, programming error #11.") end

x = parseCommand('LMLMLMLMM')
if not (x == '1 3 N') then error("Oops, programming error #12.") end

x = parseCommand('3 3 E')
if not (x == '3 3 E') then error("Oops, programming error #13.") end

x = parseCommand('M')
if not (x == '4 3 E') then error("Oops, programming error #14.") end

x = parseCommand('M')
if not (x == '5 3 E') then error("Oops, programming error #15.") end

x = parseCommand('R')
if not (x == '5 3 S') then error("Oops, programming error #16.") end

x = parseCommand('M')
if not (x == '5 2 S') then error("Oops, programming error #17.") end

x = parseCommand('M')
if not (x == '5 1 S') then error("Oops, programming error #18.") end

x = parseCommand('R')
if not (x == '5 1 W') then error("Oops, programming error #19.") end

x = parseCommand('M')
if not (x == '4 1 W') then error("Oops, programming error #20.") end

x = parseCommand('R')
if not (x == '4 1 N') then error("Oops, programming error #21.") end

x = parseCommand('R')
if not (x == '4 1 E') then error("Oops, programming error #22.") end

x = parseCommand('M')
if not (x == '5 1 E') then error("Oops, programming error #23.") end

x = parseCommand('3 3 E')
if not (x == '3 3 E') then error("Oops, programming error #24.") end

x = parseCommand('MMRMMRMRRM')
if not (x == '5 1 E') then error("Oops, programming error #25.") end
