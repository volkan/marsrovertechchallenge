i_ptX = 0
i_ptY = 0
s_direction = ''
validDirections = 'NSEW'
northDirection = 'N'
southDirection = 'S'
eastDirection = 'E'
westDirection = 'W'
validCommands = 'LRM'
leftCommand = 'L'
rightCommand = 'R'
moveCommand = 'M'

isDebugMode = False

def debugOut(msg):
    if (isDebugMode):
        print msg

def publish_values():
    if (isDebugMode):
        print '='*40
    print i_ptX, i_ptY, s_direction
    if (isDebugMode):
        print '='*40
        print 

def doMove():
    global i_ptX, i_ptY
    if (s_direction == northDirection):
        debugOut ('doMove().1 --> (s_direction == northDirection)')
        i_ptY = i_ptY + 1
    elif (s_direction == eastDirection):
        debugOut('doMove().2 --> (s_direction == eastDirection)')
        i_ptX = i_ptX + 1
    elif (s_direction == southDirection):
        debugOut('doMove().3 --> (s_direction == southDirection)')
        i_ptY = i_ptY - 1
    elif (s_direction == westDirection):
        debugOut('doMove().4 --> (s_direction == westDirection)')
        i_ptX = i_ptX - 1

def doSpin(d):
    global s_direction
    s_direction = d if ( (validDirections.find(d) > -1) or (validCommands.find(d) > -1) ) else s_direction
    debugOut('doSpin().1 --> d='+d+', s_direction='+s_direction)

def doCommand(c):
    debugOut('doCommand().1 --> c='+c)
    if (c == leftCommand):
        debugOut('doCommand().2 --> (c == leftCommand)')
        if (s_direction == northDirection):
            debugOut('doCommand().3 --> doSpin(westDirection)')
            doSpin(westDirection)
        elif (s_direction == westDirection):
            debugOut('doCommand().4 --> doSpin(southDirection)')
            doSpin(southDirection)
        elif (s_direction == southDirection):
            debugOut('doCommand().5 --> doSpin(eastDirection)')
            doSpin(eastDirection)
        elif (s_direction == eastDirection):
            debugOut('doCommand().6 --> doSpin(northDirection)')
            doSpin(northDirection)
    elif (c == rightCommand):
        debugOut('doCommand().7 --> (c == rightCommand)')
        if (s_direction == northDirection):
            debugOut('doCommand().8 --> doSpin(eastDirection)')
            doSpin(eastDirection)
        elif (s_direction == eastDirection):
            debugOut('doCommand().9 --> doSpin(southDirection)')
            doSpin(southDirection)
        elif (s_direction == southDirection):
            debugOut('doCommand().10 --> doSpin(westDirection)')
            doSpin(westDirection)
        elif (s_direction == westDirection):
            debugOut('doCommand().11 --> doSpin(northDirection)')
            doSpin(northDirection)
    elif (c == moveCommand):
        debugOut('doCommand().12 --> (c == moveCommand)')
        doMove()

def parseCommand(c):
    global i_ptX, i_ptY, s_direction
    tests = []
    items = []
    toks = c.split(' ')
    for aTok in toks:
        debugOut('parseCommand().1 aTok='+aTok)
        if (len(aTok) > 1):
            for aCmd in aTok:
                debugOut('parseCommand().2 aCmd='+aCmd)
                doCommand(aCmd)
        else:
            b = aTok.isdigit()
            debugOut('parseCommand().3 aTok='+aTok+', b='+str(b))
            if (b):
                tests.append(b)
                items.append(aTok)
                debugOut('parseCommand().4 tests.length=%s' % (len(tests)))
                if ( (len(tests) == 2) and (tests[0:2] == [True,True]) ):
                    i_ptX = int(items[0])
                    items = items[1:]
                    i_ptY = int(items[0])
                    items = items[1:]
                    tests = tests[2:]
            elif (validDirections.find(aTok) > -1):
                s_direction = aTok
                debugOut('parseCommand().5 s_direction='+s_direction)
            elif (validCommands.find(aTok) > -1):
                debugOut('parseCommand().6 doCommand('+aTok+')')
                doCommand(aTok)
    publish_values()

if (__name__ == '__main__'):
    parseCommand('1 2 N')
    parseCommand('LMLMLMLMM')
    assert (i_ptX == 1) and (i_ptY == 3) and (s_direction == 'N'), 'Oops, better check your algorithms to make sure they are correct...'

    parseCommand('3 3 E')
    parseCommand('MMRMMRMRRM')
    assert (i_ptX == 5) and (i_ptY == 1) and (s_direction == 'E'), 'Oops, better check your algorithms to make sure they are correct...'
    