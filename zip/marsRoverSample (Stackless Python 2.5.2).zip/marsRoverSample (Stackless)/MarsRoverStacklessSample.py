import stackless

import MarsRover

command_channel = stackless.channel()

def doCommand(aCmd):
    MarsRover.parseCommand(aCmd)

def doSpacer(s):
    print s

if (__name__ == '__main__'):
    iterativeFlag = False
    _commands = ['1 2 N','LMLMLMLMM','3 3 E','MMRMMRMRRM']
    commands = [False] + _commands + [True] + _commands
    for aCmd in commands:
        isBool = aCmd in [True,False]
        if (isBool):
            iterativeFlag = aCmd
            stackless.tasklet(doSpacer)('*'*10)
            continue
        toks = aCmd.split()
        if (not iterativeFlag) or (len(toks) > 1):
            stackless.tasklet(doCommand)(aCmd)
        else:
            for cmd in aCmd:
                stackless.tasklet(doCommand)(cmd)
            stackless.tasklet(doSpacer)('='*10)
    stackless.run()
